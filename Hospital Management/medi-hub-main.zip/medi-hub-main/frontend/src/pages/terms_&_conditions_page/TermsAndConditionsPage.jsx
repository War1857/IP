import React from "react";

function TermsAndConditionsPage() {
  return <div>Terms and Conditions</div>;
}

export default TermsAndConditionsPage;
