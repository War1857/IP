import React from "react";
import { AppointmentLocation } from "../import-export/ImportExport";

function Appointment() {
  return (
    <>
      <AppointmentLocation />
    </>
  );
}

export default Appointment;
