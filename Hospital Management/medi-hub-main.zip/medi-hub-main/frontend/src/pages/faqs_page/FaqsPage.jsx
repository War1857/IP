import React from "react";
import { FaqsCard } from "../../import-export/ImportExport";

function FaqsPage() {
  return (
    <div>
      <FaqsCard />
    </div>
  );
}

export default FaqsPage;
