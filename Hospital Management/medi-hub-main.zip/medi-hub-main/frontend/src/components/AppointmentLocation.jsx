import React from 'react'

function AppointmentLocation() {
  return (
    <div>AppointmentLocation</div>
  )
}

export default AppointmentLocation