import React from 'react'

function Home() {
    return (
        <div className="text-3xl font-bold underline">Home</div>
    )
}

export default Home