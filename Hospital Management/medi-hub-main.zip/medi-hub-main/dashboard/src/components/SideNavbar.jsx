import React from "react";

function SideNavbar() {
  return <div>SideNavbar</div>;
}

export default SideNavbar;
