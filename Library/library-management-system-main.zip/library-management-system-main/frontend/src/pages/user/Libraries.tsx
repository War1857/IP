const Libraries = () => {
    return (
        <div>
            All libraries
        </div>
    );
};

export default Libraries;
