module.exports = {
    GOOGLE_CLIENT_ID: process.env.GOOGLE_CLIENT,
    GOOGLE_CLIENT_SECRET: process.env.GOOGLE_SECRET,
    mongoURI: process.env.MONGO_URI,
    cookieKey: process.env.COOKIE_KEY
}