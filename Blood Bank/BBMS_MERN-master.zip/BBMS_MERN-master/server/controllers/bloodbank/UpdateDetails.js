import React from 'react'

const UpdateDetails =()=>{
    return(
        <div>

        </div>
    )
}
export default UpdateDetails;