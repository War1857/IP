# Contributions are always appreciated 🤍

Those who wish to contribute to the repository kindly follow these rules:

- **fork** the repository
- write the details about the changes or the contributions you want to make and raise an `issue`.
- Once the issue get reviewed and ideated. Follow good coding practices to implement the code and raise a `pull request`
- Proper comments and meaning full messages in the code as well as PR is much appreciated.
- If there are no issue with the code your PR will be merged with the main branch.
- Happy contributing...!
