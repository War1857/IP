import React from "react";

//css
import "../../assets/css/Footer.css";

const Footer = () => {
  return (
    <div className="footer">
      <a href="/login/emp">EMP LOGIN</a>
    </div>
  );
};

export default Footer;
