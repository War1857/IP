import React from "react";

const SearchPage = () => {
  return (
    <div>
      <a href="/home/search/blood">
        <i className="fa fa-search" />
      </a>
    </div>
  );
};
export default SearchPage;
