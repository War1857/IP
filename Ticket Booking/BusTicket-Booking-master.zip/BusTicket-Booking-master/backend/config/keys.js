module.exports = {
    MongoURI: "mongodb+srv://vivek:123@cluster0.9mrxijd.mongodb.net/?retryWrites=true&w=majority"

}