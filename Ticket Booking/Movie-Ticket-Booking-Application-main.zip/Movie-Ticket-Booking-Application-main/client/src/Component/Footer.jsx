import React, { Component } from 'react';

function Footer()
{
    return (
        <div className="bottom">

        <center><h2>MoviesNow</h2></center>
        <center>
            <div className="icons">
                <i className="fab fa-facebook"></i>
                <i className="fab fa-twitter"></i>
                <i className="fab fa-instagram"></i>
                <i className="fab fa-reddit"></i>
            </div>
        </center>
        <center><h3> Copyrights.All rights reserved</h3></center>
        
    </div>
    );
}

export default Footer;