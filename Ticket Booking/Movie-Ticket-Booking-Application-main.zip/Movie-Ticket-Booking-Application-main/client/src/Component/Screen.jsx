import React, { Component } from 'react';

function Screen()
{
    return (
        <div>

        </div>
    );
}

export default Screen;