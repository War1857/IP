import React, { Component } from 'react';

function CastBar() {
    
    return (
        <div className="">
            
        </div>

    );
}

export default CastBar;