#you have to install node module
#.env file

****\*\***** .env
ATLAS_URI=<copy your mongodb url>
