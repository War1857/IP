| Username | email id | skills |
| :----- | :-------- | :----------------: |
| Ambati Harika | ambati.harika666@gmail.com| SQL, C++ ,DSA ,Python,ML |