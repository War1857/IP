| Username | email id | skills |
| :----- | :-------- | :----------------: |
| Gunavardhan | gunavardhan000@gmail.com | SQL, PYTHON ,DSA ,Autodidact,Philomath |