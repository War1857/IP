# Pravallika Maturi

| Username | email id | skills |
| :----- | :-------- | :----------------: |
| Pravallika.Maturi | maturipravallika8422@gmail.com | Python, JavaScript |

## Contribution