# Amruta Jayanti

| Username | email id | skills |
| :----- | :-------- | :----------------: |
| AmrutaJayanti | amruta2004.jayanti@gmail.com | Python ,Html ,CSS ,Javascript |

## Contribution
