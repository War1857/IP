# Dinesh Senapathi

| Username | email id | skills |
| :----- | :-------- | :----------------: |
| dineshsenapathi | senapathidinesh.in@gmail.com | Python, JavaScript, Node.js |

## Contribution