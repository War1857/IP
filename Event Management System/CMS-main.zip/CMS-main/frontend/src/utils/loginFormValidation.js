function isLoginFormValid(email) {
    
}