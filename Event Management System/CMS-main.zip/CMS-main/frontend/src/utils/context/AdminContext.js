import { createContext } from "react";

const AdminContext = createContext(null);

export default AdminContext;