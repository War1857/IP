export { default as person3 } from './person3.jpeg'

export { default as contact } from "./contact.jpg"

export { default as crm } from "./crm.png"
export { default as banklandingpage } from "./banklandingpage.png"
export { default as deziskin } from "./deziskin.png"
export { default as doctorguide } from "./doctorguide.png"
export { default as musify } from "./musify.png"
export { default as ncexercises } from "./ncexercises.png"
export { default as portfolio } from "./portfolio.png"
export { default as shoppy } from "./shoppy.png"
export { default as swiftcartDashboard} from "./swiftcart-dashboard.png"
export { default as swiftcartStore } from "./swiftcart-store.png"

export { default as profile } from "./profile.png"
export { default as huzaifa } from "./huzaifa.png"
export { default as muneeb } from "./muneeb.png"

export { default as empty } from "./empty.png"